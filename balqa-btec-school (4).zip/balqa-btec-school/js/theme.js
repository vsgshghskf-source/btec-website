/* الوضع الداكن / الفاتح */
var R=document.documentElement;
try{var t=localStorage.getItem("theme");if(t)R.dataset.theme=t}catch(e){}
document.getElementById("tg").onclick=function(){
 var cur=R.dataset.theme||(matchMedia("(prefers-color-scheme: light)").matches?"light":"dark"),nx=cur=="dark"?"light":"dark";
 R.dataset.theme=nx;try{localStorage.setItem("theme",nx)}catch(e){}};
