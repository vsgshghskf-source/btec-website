/* لعبة تحدّي BTEC (الأسئلة في data.js) */
var G={},BEST=0,gm=document.getElementById('gm');
function sh(a){return a.slice().sort(function(){return Math.random()-.5})}
function gStart(){G={q:sh(Q).slice(0,10),i:0,s:0,st:0,l:3,t:15,id:0,lock:0,ok:0};gNext()}
function gNext(){
 if(G.i>=G.q.length||G.l<=0)return gEnd();
 var q=G.q[G.i];G.t=15;G.lock=0;
 gm.innerHTML='<div class="hud"><span>⭐ '+G.s+'</span><span>🔥 '+G.st+'</span><span>'+'❤️'.repeat(G.l)+'</span><span>'+(G.i+1)+'/'+G.q.length+'</span></div><div class="tm"><i id="tmb"></i></div><div class="q">'+q[0]+'</div><div class="ans">'+sh(q[1].map(function(t,k){return[t,k]})).map(function(o){return'<button data-k="'+o[1]+'">'+o[0]+'</button>'}).join('')+'</div><div class="fb" id="fb"></div>';
 G.id=setInterval(function(){G.t-=.1;var b=document.getElementById('tmb');if(b)b.style.width=Math.max(0,G.t/15*100)+'%';if(G.t<=0)gAns(null)},100)}
function gAns(b){
 if(G.lock)return;G.lock=1;clearInterval(G.id);
 var q=G.q[G.i],k=b?+b.dataset.k:-1,ok=k==q[2];
 [].forEach.call(gm.querySelectorAll('.ans button'),function(x){if(+x.dataset.k==q[2])x.classList.add('ok')});
 if(b&&!ok)b.classList.add('no');
 if(ok){G.st++;G.ok++;G.s+=10+Math.ceil(G.t)+(G.st-1)*2}else{G.st=0;G.l--}
 var f=document.getElementById('fb');if(f)f.textContent=(ok?'✅ أحسنت! ':(b?'❌ ':'⏰ انتهى الوقت. '))+q[3];
 G.i++;setTimeout(gNext,1900)}
function gEnd(){
 BEST=Math.max(BEST,G.s);
 var r=G.s<100?['مستكشف','🌱']:G.s<200?['متمرّس','⚡']:['خبير BTEC','👑'];
 gm.innerHTML='<div class="end"><div style="font-size:64px">'+r[1]+'</div><h3>'+r[0]+'</h3><p>نتيجتك: <b>'+G.s+'</b> نقطة — إجابات صحيحة: '+G.ok+' من '+G.q.length+'</p><p>أفضل نتيجة في هذه الجلسة: '+BEST+'</p><button class="btn b1" data-a="start">العب مرة أخرى</button></div>'}
gm.onclick=function(e){var b=e.target.closest('button');if(!b)return;if(b.dataset.a=='start')gStart();else if(b.dataset.k!=null)gAns(b)};
