/* تبويبات التخصصات */
var tabs=document.getElementById("tabs"),panel=document.getElementById("panel");
function li(a){return a.map(function(x){return"<li>"+x+"</li>"}).join("")}
function show(n){
 var p=S[n];panel.style.setProperty("--k",p.k);
 [].forEach.call(tabs.children,function(b,j){b.setAttribute("aria-selected",j==n)});
 panel.style.animation="none";void panel.offsetWidth;panel.style.animation="";
 panel.innerHTML='<span class="big">'+p.i+'</span><h3>'+p.n+'</h3><p>'+p.d+'</p><div class="cols"><div><h5>ماذا ستتعلّم؟</h5><ul>'+li(p.l)+'</ul></div><div><h5>مهارات تكتسبها</h5><div class="chips">'+p.s.map(function(x){return"<span>"+x+"</span>"}).join("")+'</div></div><div><h5>آفاق العمل</h5><ul>'+li(p.j)+'</ul></div></div><div class="cols"><div><h5>لمن يناسب هذا التخصص؟</h5><ul>'+li(X[n].f)+'</ul></div><div><h5>أمثلة على المشاريع</h5><ul>'+li(X[n].p)+'</ul></div></div>';
}
S.forEach(function(p,n){var b=document.createElement("button");b.className="tab";b.setAttribute("role","tab");b.style.setProperty("--k",p.k);b.textContent=p.i+" "+p.n;b.onclick=function(){show(n)};tabs.appendChild(b)});
show(0);
