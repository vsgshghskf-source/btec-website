/* بوابة الدخول */
var gate=document.getElementById("gate");document.body.style.overflow="hidden";
function openGate(e){if(e&&e.detail>0){gate.style.setProperty("--cx",e.clientX+"px");gate.style.setProperty("--cy",e.clientY+"px")}gate.classList.add("open");setTimeout(function(){gate.remove();document.body.style.overflow=""},1300)}
document.getElementById("enter").onclick=openGate;
document.getElementById("skip").onclick=function(){gate.remove();document.body.style.overflow=""};
