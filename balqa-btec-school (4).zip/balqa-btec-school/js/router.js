/* التنقل بين الصفحات (hash routing) */
var PG=[].slice.call(document.querySelectorAll(".pg")),NV=[].slice.call(document.querySelectorAll("nav a"));
function route(){var h=location.hash.slice(1);if(!PG.some(function(e){return e.dataset.p==h}))h="home";
 PG.forEach(function(e){e.classList.toggle("show",e.dataset.p==h)});
 NV.forEach(function(a){a.classList.toggle("act",a.getAttribute("href")=="#"+h)});var ac=document.querySelector("nav a.act");if(ac&&ac.scrollIntoView)ac.scrollIntoView({inline:"center",block:"nearest"});scrollTo(0,0)}
addEventListener("hashchange",route);route();
