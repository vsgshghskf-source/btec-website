الموقع يحمّل خط Tajawal من Google Fonts عبر رابط في index.html (يحتاج إنترنت).
للعمل دون اتصال: نزّل ملفات الخط من fonts.google.com/specimen/Tajawal
وضعها هنا، ثم أضف قواعد @font-face في css/base.css واحذف رابط Google Fonts من index.html.
